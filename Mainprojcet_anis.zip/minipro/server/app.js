var express= require("express")
var products=require('./model/products')
var mongoose=require('mongoose');
var bodyparser=require('body-parser');
var url="mongodb://127.0.0.1:27017/minipro";
const app=express();
app.use(bodyparser.urlencoded({extended:true}));
app.use(bodyparser.json());
mongoose.connect(url, function (err){
    if (err) throw err
    else {
        console.log("connection established")
    }

})
app.get("/data", function (req,res){
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE'); // If needed
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type'); // If needed
    res.setHeader('Access-Control-Allow-Credentials', true); // If needed

products.find({},function(err,result){
    if (err) throw err
    else {
        res.send(result)
    }
})
})
app.post("/insert",function(req,res){
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE'); // If needed
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type'); // If needed
    res.setHeader('Access-Control-Allow-Credentials', true); // If needed
console.log(req.body);
    var prd=new products();
    prd.dress=req.body.dress;
    prd.brand=req.body.brand;
    prd.prize=req.body.prize;
   
    prd.save(function(err){
        if (err) throw err
        else{
            res.send({msg:"data inserted"})
        }
    })
})
app.listen(8000,function(){
    console.log("server started Listening port 8000......");
});