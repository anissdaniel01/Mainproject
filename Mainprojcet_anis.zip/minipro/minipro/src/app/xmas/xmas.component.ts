import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Component({
  selector: 'app-xmas',
  templateUrl: './xmas.component.html',
  styleUrls: ['./xmas.component.css']
})
export class XmasComponent implements OnInit {
  msg;
  message;
  dress;
  brand;
  prize:Number
  constructor(private http:HttpClient) { }

  ngOnInit() {
  }
  AddProduct(){ 
    var url="http://localhost:8000/insert";
    var data={dress:this.dress, brand:this.brand,prize:this.prize};
    this.http.post(url, data).subscribe(data=>{
      console.log(data);
      this.message = data;
    })

  }
  imageUrl:string="assets/images/image2.jpg";
  }
