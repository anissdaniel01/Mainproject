import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {StorageServiceModule} from 'angular-webstorage-service'
import {RouterModule,Routes, Router} from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import {HttpClientModule} from '@angular/common/http';
import{SignupComponent} from './signup/signup.component'
import { NewProductComponent } from './new-product/new-product.component';
import { ViewProductComponent } from './view-product/view-product.component';
import {HomeProductComponent} from './home-product/home-product.component';
import {LoginProductComponent} from './login-product/login-product.component';
import {SampleService} from './sample.service';
import {UserService} from './user.service';
import {CalcService} from './calc.service';
import { TestComponent } from './test/test.component';
import { FooterComponent } from './footer/footer.component';

import { AdminComponent } from './admin/admin.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { XmasComponent } from './xmas/xmas.component';
import { BoysComponent } from './boys/boys.component';
import { GirlsComponent } from './girls/girls.component';
import { LogoutComponent } from './logout/logout.component';


const routes:Routes=[
                 
                    {path:"", component:HomeProductComponent},
                    {path:'home',component:HomeProductComponent},
                    {path:'login',component:LoginProductComponent},
                    {path:"signup",component:SignupComponent},
                    {path:"new", component:NewProductComponent},
                    {path:"view", component:ViewProductComponent},
                    {path:"test", component:TestComponent},
                    {path:"xmas", component:XmasComponent},
                    {path:"boys", component:BoysComponent},
                    {path:"girls", component:GirlsComponent}



                   
                  ];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeProductComponent,
    LoginProductComponent,
    SignupComponent,
    NewProductComponent,
    ViewProductComponent,
    TestComponent,
    SignupComponent,
    FooterComponent,
    AdminComponent,
    MainNavComponent,
    XmasComponent,
    BoysComponent,
    GirlsComponent,
    LogoutComponent,
    // MatSidenavModule
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    //   {
    //     path:'admin',
    //     component:AdminComponent
    //   },
    //   {
    //     path:'login',
    //     component:LoginProductComponent
    //   },
    //   {
    //     path:'',
    //     component:HomeProductComponent
    //   }
    // ]),
    HttpClientModule, StorageServiceModule, LayoutModule, MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule

  ],
  providers: [SampleService, CalcService, UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
